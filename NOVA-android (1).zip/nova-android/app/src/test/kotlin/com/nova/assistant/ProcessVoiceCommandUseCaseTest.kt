package com.nova.assistant

import com.nova.assistant.domain.model.VoiceIntent
import com.nova.assistant.domain.usecase.ProcessVoiceCommandUseCase
import com.google.common.truth.Truth.assertThat
import org.junit.Before
import org.junit.Test

class ProcessVoiceCommandUseCaseTest {

    private lateinit var useCase: ProcessVoiceCommandUseCase

    @Before
    fun setup() {
        useCase = ProcessVoiceCommandUseCase()
    }

    @Test
    fun `wake phrase detected`() {
        val cmd = useCase("hi nova")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.WAKE)
    }

    @Test
    fun `stop command detected`() {
        val cmd = useCase("stop nova")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.STOP)
    }

    @Test
    fun `pause command detected`() {
        val cmd = useCase("pause")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.PAUSE)
    }

    @Test
    fun `resume command detected`() {
        val cmd = useCase("resume")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.RESUME)
    }

    @Test
    fun `call intent detected`() {
        val cmd = useCase("call John Smith")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.CALL)
        assertThat(cmd.extras["contact"]).isEqualTo("john smith")
    }

    @Test
    fun `set reminder intent detected`() {
        val cmd = useCase("remind me to take medication")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.SET_REMINDER)
    }

    @Test
    fun `set timer intent detected`() {
        val cmd = useCase("set timer for 5 minutes")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.SET_TIMER)
    }

    @Test
    fun `add todo intent detected`() {
        val cmd = useCase("add task buy groceries")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.ADD_TODO)
    }

    @Test
    fun `web search intent detected`() {
        val cmd = useCase("search for best coffee shops")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.WEB_SEARCH)
        assertThat(cmd.extras["query"]).contains("best coffee shops")
    }

    @Test
    fun `open app intent detected`() {
        val cmd = useCase("open spotify")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.OPEN_APP)
    }

    @Test
    fun `flashlight on intent detected`() {
        val cmd = useCase("turn on flashlight")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.FLASHLIGHT_ON)
    }

    @Test
    fun `flashlight off intent detected`() {
        val cmd = useCase("flashlight off")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.FLASHLIGHT_OFF)
    }

    @Test
    fun `general query falls through to QUERY`() {
        val cmd = useCase("What is the capital of France?")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.QUERY)
    }

    @Test
    fun `case insensitive matching`() {
        val cmd = useCase("HI NOVA")
        assertThat(cmd.intent).isEqualTo(VoiceIntent.WAKE)
    }
}

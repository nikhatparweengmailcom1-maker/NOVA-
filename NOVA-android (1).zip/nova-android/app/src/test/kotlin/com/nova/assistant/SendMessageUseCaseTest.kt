package com.nova.assistant

import com.nova.assistant.domain.model.AIResponse
import com.nova.assistant.domain.model.ErrorCode
import com.nova.assistant.domain.repository.ChatRepository
import com.nova.assistant.domain.usecase.SendMessageUseCase
import com.google.common.truth.Truth.assertThat
import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.Before
import org.junit.Test

class SendMessageUseCaseTest {

    private lateinit var repository: ChatRepository
    private lateinit var useCase: SendMessageUseCase

    @Before
    fun setup() {
        repository = mockk()
        useCase = SendMessageUseCase(repository)
    }

    @Test
    fun `invoke returns AI success response`() = runTest {
        val expected = AIResponse.Success(
            text = "Hello, how can I help?",
            provider = "openai",
            model = "gpt-4o-mini"
        )
        coEvery {
            repository.sendMessage("conv-1", "Hi", false)
        } returns expected

        val result = useCase("conv-1", "Hi")

        assertThat(result).isEqualTo(expected)
        coVerify(exactly = 1) { repository.sendMessage("conv-1", "Hi", false) }
    }

    @Test
    fun `invoke returns error when API key missing`() = runTest {
        val expected = AIResponse.Error("API key not set", ErrorCode.API_KEY_MISSING)
        coEvery {
            repository.sendMessage(any(), any(), any())
        } returns expected

        val result = useCase("conv-1", "Hi")

        assertThat(result).isInstanceOf(AIResponse.Error::class.java)
        val error = result as AIResponse.Error
        assertThat(error.code).isEqualTo(ErrorCode.API_KEY_MISSING)
    }

    @Test
    fun `invoke with voice flag passes through`() = runTest {
        val expected = AIResponse.Success("response", "openai", "gpt-4o-mini")
        coEvery {
            repository.sendMessage("conv-1", "Voice input", true)
        } returns expected

        useCase("conv-1", "Voice input", isVoice = true)

        coVerify { repository.sendMessage("conv-1", "Voice input", true) }
    }

    @Test
    fun `invoke handles network error`() = runTest {
        val expected = AIResponse.Error("Network error", ErrorCode.NETWORK_ERROR)
        coEvery { repository.sendMessage(any(), any(), any()) } returns expected

        val result = useCase("conv-1", "test")

        assertThat(result).isInstanceOf(AIResponse.Error::class.java)
        assertThat((result as AIResponse.Error).code).isEqualTo(ErrorCode.NETWORK_ERROR)
    }
}

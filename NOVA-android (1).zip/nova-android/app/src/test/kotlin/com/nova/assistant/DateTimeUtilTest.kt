package com.nova.assistant

import com.nova.assistant.util.DateTimeUtil
import com.google.common.truth.Truth.assertThat
import org.junit.Test

class DateTimeUtilTest {

    @Test
    fun `parseDurationPhrase parses minutes`() {
        val duration = DateTimeUtil.parseDurationPhrase("5 minutes")
        assertThat(duration).isEqualTo(5 * 60 * 1000L)
    }

    @Test
    fun `parseDurationPhrase parses hours`() {
        val duration = DateTimeUtil.parseDurationPhrase("2 hours")
        assertThat(duration).isEqualTo(2 * 3600 * 1000L)
    }

    @Test
    fun `parseDurationPhrase parses combined`() {
        val duration = DateTimeUtil.parseDurationPhrase("1 hour and 30 minutes")
        assertThat(duration).isEqualTo((3600 + 30 * 60) * 1000L)
    }

    @Test
    fun `parseDurationPhrase returns null for unrecognized`() {
        val duration = DateTimeUtil.parseDurationPhrase("no duration here")
        assertThat(duration).isNull()
    }

    @Test
    fun `getDurationLabel formats seconds`() {
        val label = DateTimeUtil.getDurationLabel(90_000L)
        assertThat(label).isEqualTo("01:30")
    }

    @Test
    fun `getDurationLabel formats hours`() {
        val label = DateTimeUtil.getDurationLabel(3661_000L)
        assertThat(label).isEqualTo("1:01:01")
    }

    @Test
    fun `formatDate returns non-empty string`() {
        val date = DateTimeUtil.formatDate(System.currentTimeMillis())
        assertThat(date).isNotEmpty()
    }

    @Test
    fun `formatTime returns non-empty string`() {
        val time = DateTimeUtil.formatTime(System.currentTimeMillis())
        assertThat(time).isNotEmpty()
    }

    @Test
    fun `parseNaturalDatePhrase parses tomorrow`() {
        val result = DateTimeUtil.parseNaturalDatePhrase("tomorrow")
        assertThat(result).isNotNull()
        assertThat(result!!).isGreaterThan(System.currentTimeMillis())
    }

    @Test
    fun `parseNaturalDatePhrase parses in an hour`() {
        val before = System.currentTimeMillis()
        val result = DateTimeUtil.parseNaturalDatePhrase("in an hour")
        assertThat(result).isNotNull()
        assertThat(result!!).isGreaterThan(before + 59 * 60_000L)
    }

    @Test
    fun `parseNaturalDatePhrase returns null for unknown`() {
        val result = DateTimeUtil.parseNaturalDatePhrase("on some random day")
        assertThat(result).isNull()
    }
}
